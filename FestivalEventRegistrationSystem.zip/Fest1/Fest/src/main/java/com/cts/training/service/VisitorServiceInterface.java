package com.cts.training.service;

import java.util.List;

import com.cts.training.bean.VisitorBean;
import com.cts.training.entity.VisitorEntity;

public interface VisitorServiceInterface {
	void saveVisitor(VisitorBean visitorBean);

	String validateVisitorLogin(String userName, String passWord);

	List<VisitorEntity> getVisitor(String userName);

	VisitorEntity getVisitorObject(String userName);
	VisitorEntity getVisitor(int visitorId);
	VisitorEntity updateVisitorObject(VisitorBean visitorBean);
	boolean changePassword(String userName,String passWord);
	int getId(String userName);

}
